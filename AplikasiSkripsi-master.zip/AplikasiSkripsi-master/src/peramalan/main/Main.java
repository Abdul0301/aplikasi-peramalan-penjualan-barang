package peramalan.main;

/**
 *
 * @author 6P52
 */
public class Main {
    
}