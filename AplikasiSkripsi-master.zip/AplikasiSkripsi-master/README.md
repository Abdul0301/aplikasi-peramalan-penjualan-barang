# AplikasiSkripsi
Aplikasi sistem peramalan jumlah pembeliaan bahan baku kayu dengan metode single exponential smoothing mengunakan java
